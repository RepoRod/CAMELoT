'use strict';

describe('myApp.ferramenta module', function() {

  beforeEach(module('myApp.ferramenta'));

  describe('ferramenta controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var ferramentaCtrl = $controller('Ferramenta1Ctrl');
      expect(FerramentaCtrl).toBeDefined();
    }));

  });
});