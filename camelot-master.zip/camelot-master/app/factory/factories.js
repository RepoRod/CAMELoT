/**
 * Created by danie on 31/12/2016.
 */

angular.module('myApp.factories', []);